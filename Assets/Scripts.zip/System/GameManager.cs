using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    [SerializeField] private PlayerController _player;
    [SerializeField] private List<SectionGroup> _sectionGroups;

    private SectionGroup _lastSection;
    private int _currentSectionGroupIndex = 0;

    private void Awake()
    {
        Application.targetFrameRate = 60;
        
        GameStart();
    }

    private void GameStart()
    {
        _currentSectionGroupIndex = 0;
        StartSection(_currentSectionGroupIndex);
    }

    private void StartSection(int sectionGroupIndex)
    {
        var targetSection = _sectionGroups[sectionGroupIndex];

        EventManager.Attach(GameEventType.SectionGroupClear, targetSection, OnClearSectionGroup);
        targetSection.ActiveSection(_player);
    }

    private void OnClearSectionGroup(EventEmitter eventEmitter)
    {
        if (IsAllClear())
        {
            EndGame();
            return;
        }

        _currentSectionGroupIndex++;
        EventManager.Detach(GameEventType.SectionGroupClear, eventEmitter, OnClearSectionGroup);

        StartSection(_currentSectionGroupIndex);
    }

    private bool IsAllClear()
    {
        return _currentSectionGroupIndex >= _sectionGroups.Count;
    }

    private void EndGame()
    {

    }

}
