using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class GameSection : EventEmitter
{
    public bool IsClear { get; private set; }

    public abstract void ActiveSection(PlayerController player);
    protected virtual void ClearSection()
    {
        TriggerEvent(GameEventType.SectionClear);
    }
}
