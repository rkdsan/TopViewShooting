using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class SectionGroup : GameSection
{
    [SerializeField] private List<GameSection> sections;

    public override void ActiveSection(PlayerController player)
    {
        foreach (var section in sections)
        {
            EventManager.Attach(GameEventType.SectionClear, section, OnClearSection);
            section.ActiveSection(player);
        }
    }

    private void OnClearSection(EventEmitter eventEmitter)
    {
        bool isAllClear = sections.All(t => t.IsClear);
        if (isAllClear)
        {
            ClearSection();
        }
    }
}
