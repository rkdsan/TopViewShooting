using UnityEngine;

public abstract class EventEmitter : MonoBehaviour
{
    protected void TriggerEvent(GameEventType eventType)
    {
        EventManager.TriggerEvent(eventType, this);
    }
}
