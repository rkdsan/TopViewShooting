using System;
using System.Collections.Generic;

public enum GameEventType
{
    OnPlayerEnter,
    OnPlayerExit,
    OnDeadMonster,
    SectionClear,
    SectionGroupClear,
}

public static class EventManager
{

    public static Dictionary<GameEventType, Dictionary<EventEmitter, Action<EventEmitter>>> eventDictionary = new Dictionary<GameEventType, Dictionary<EventEmitter, Action<EventEmitter>>>();

    public static void Attach(GameEventType eventType, EventEmitter subject, Action<EventEmitter> action)
    {
        if (!eventDictionary.ContainsKey(eventType))
        {
            eventDictionary[eventType] = new Dictionary<EventEmitter, Action<EventEmitter>>();
        }

        if (!eventDictionary[eventType].ContainsKey(subject))
        {
            eventDictionary[eventType][subject] = action;
        }
        else
        {
            eventDictionary[eventType][subject] += action;
        }
    }

    public static void Detach(GameEventType eventType, EventEmitter subject, Action<EventEmitter> action)
    {
        if (!HasKey(eventType, subject))
            return;

        eventDictionary[eventType][subject] -= action;
    }

    public static void TriggerEvent(GameEventType eventType, EventEmitter subject)
    {
        if (!HasKey(eventType, subject))
            return;

        eventDictionary[eventType][subject]?.Invoke(subject);
    }

    private static bool HasKey(GameEventType eventType, EventEmitter subject)
    {
        if (!eventDictionary.ContainsKey(eventType))
            return false;

        if (!eventDictionary[eventType].ContainsKey(subject))
            return false;

        return true;
    }

}