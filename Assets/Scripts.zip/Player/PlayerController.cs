using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour, IDamageable
{
    [SerializeField] private Weapon _weapon;
    [SerializeField] private float _moveSpeed = 3;
    private PlayerView _playerView;
    private Rigidbody _rigidbody;
    private CharacterController _characterController;

    private Camera _mainCamera;

    private Vector2 _moveInputVector;
    

    private void Awake()
    {
        _mainCamera = Camera.main;
        _playerView = GetComponent<PlayerView>();
        _rigidbody = GetComponent<Rigidbody>();
        _characterController = GetComponent<CharacterController>();
    }

    private void Update()
    {
        Move();
        Rotation();
    }


    public void TakeDamage(int damage)
    {
        
    }

    private void SetHealth(int newHealth)
    {

    }

    private void Move()
    {
        var moveVector = _moveInputVector * _moveSpeed * Time.deltaTime;
        var addPosition = new Vector3(moveVector.x, 0, moveVector.y);

        //_characterController.Move(addPosition);
        //_characterController.SimpleMove(addPosition);
        _rigidbody.MovePosition(transform.position + addPosition);

        _playerView.OnPlayerMove(moveVector);
    }

    private void Rotation()
    {
        var myPosition = _mainCamera.WorldToScreenPoint(transform.position);
        var mousePosition = Input.mousePosition;

        var angle = Mathf.Atan2(mousePosition.y - myPosition.y, mousePosition.x - myPosition.x) * Mathf.Rad2Deg;

        transform.rotation = Quaternion.Euler(new Vector3(0, -angle + 90, 0));
    }

    #region PlayerInput
    private void OnMove(InputValue inputValue)
    {
        _moveInputVector = inputValue.Get<Vector2>().normalized;
    }

    private void OnAttack()
    {
        _weapon.Attack();
        _playerView.OnPlayerAttack();
    }

    private void OnJump()
    {

    }

    #endregion
}
