using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{
    [SerializeField] private Slider _healthGauge;
    [SerializeField] private TextMeshProUGUI _healthText;

    public void OnUpdateHealth(int currentHP, int maxHP)
    {
        _healthGauge.value = (float)currentHP / maxHP;
        _healthText.text = $"{currentHP}";
    }

}
