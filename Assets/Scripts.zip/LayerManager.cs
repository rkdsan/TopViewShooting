
using UnityEngine;

public static class LayerManager
{
    public static LayerMask CombatTargetLayer = LayerMask.GetMask("CombatTarget");

}
