using System;
using UnityEngine;
using UnityEngine.AI;

public class Monster : EventEmitter, IDamageable
{
    [SerializeField] private Transform _ttemp;
    [SerializeField] private HealthBar _healthBar;

    public bool IsDead { get; private set; }

    private NavMeshAgent _navMeshAgent;
    private Transform _followTarget;

    private int _currentHealth;
    private int _maxHealth;

    private void Awake()
    {
        _navMeshAgent = GetComponent<NavMeshAgent>();
        Init();
        SetTarget(_ttemp);
    }

    public void SetTarget(Transform target)
    {
        _followTarget = target;
        _navMeshAgent.SetDestination(target.transform.position);
    }

    public void Init()
    {
        _currentHealth = _maxHealth = 5;
        SetHealth(_currentHealth);
    }

    public void TakeDamage(int damage)
    {
        SetHealth(_currentHealth - damage);
    }

    private void SetHealth(int newHealth)
    {
        _currentHealth = Math.Max(0, newHealth);
        _healthBar.OnUpdateHealth(_currentHealth, _maxHealth);

        if (_currentHealth == 0)
        {
            Die();
        }
    }

    private void Die()
    {
        gameObject.SetActive(false);
        TriggerEvent(GameEventType.OnDeadMonster);
    }

}
